import React, { useState, useEffect, useRef, useMemo } from "react";
import { dbInstance, ref, onValue, update } from "./firebaseConfig";
import { InverterFirebaseData, CalibrationSettings, ChartDataPoint } from "./types";
import { Gauge } from "./components/Gauge";
import { PowerChart } from "./components/PowerChart";
import { SettingsModal } from "./components/SettingsModal";
import { RelaySwitch } from "./components/RelaySwitch";
import { TimeRange, generateHistoryForRange, TIME_RANGES } from "./utils/historyData";
import {
  Sliders,
  Zap,
  Power,
  RotateCcw,
  Clock,
  TrendingUp,
  TrendingDown,
  Sun,
  BatteryCharging,
} from "lucide-react";

export default function App() {
  // Navigation tab state: 'home' | 'stat' | 'sys'
  const [activeTab, setActiveTab] = useState<"home" | "stat" | "sys">("home");

  // Settings Modal state
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Time range selection for history & chart: '1h' | '3h' | '4h' | '6h' | '12h' | '24h'
  const [selectedTimeRange, setSelectedTimeRange] = useState<TimeRange>("3h");

  // Calibration settings (Default baOff = -15 to reduce 39.5 Ah by 35 to 4.5 Ah)
  const [settings, setSettings] = useState<CalibrationSettings>(() => {
    const savedBaOff = localStorage.getItem("baOff");
    const savedVOff = localStorage.getItem("vOff");
    const savedAOff = localStorage.getItem("aOff");
    const savedBatCap = localStorage.getItem("batCap");
    const savedWhGrid = localStorage.getItem("whGrid");

    return {
      baOff: savedBaOff !== null ? parseFloat(savedBaOff) : -15,
      vOff: savedVOff !== null ? parseFloat(savedVOff) : 0,
      aOff: savedAOff !== null ? parseFloat(savedAOff) : 0,
      batCap: savedBatCap !== null ? parseFloat(savedBatCap) : 65,
      whGridInitial: savedWhGrid !== null ? parseFloat(savedWhGrid) : 116.813,
    };
  });

  // Raw Firebase telemetry data
  const [firebaseData, setFirebaseData] = useState<InverterFirebaseData>({
    solar: { voltage: 13.4, current: 0.35 },
    battery: { ah: 19.5, state: "CHARGING" },
    energy: { whIn: 142.5, whOut: 18.2, dailyWhOut: 12.4 },
    relay: { inverter: true, line: false },
    system: { status: "ONLINE", wifiRSSI: -54, ip: "192.168.1.104" },
  });

  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [connStatusText, setConnStatusText] = useState<string>("Online");
  const [demoMode, setDemoMode] = useState<boolean>(false);

  // Statistics persisted in localStorage
  const [whSolar, setWhSolar] = useState<number>(() =>
    parseFloat(localStorage.getItem("whSolar") || "3.42")
  );
  const [whGrid, setWhGrid] = useState<number>(() =>
    parseFloat(localStorage.getItem("whGrid") || "116.813")
  );
  const [maxCharge, setMaxCharge] = useState<number>(() =>
    parseFloat(localStorage.getItem("maxCharge") || "482")
  );
  const [maxLoad, setMaxLoad] = useState<number>(() =>
    parseFloat(localStorage.getItem("maxLoad") || "310")
  );

  const lastWhTotalRef = useRef<number>(0);

  // Connect to Firebase RTDB
  useEffect(() => {
    if (!dbInstance) {
      setConnStatusText("Standalone");
      return;
    }

    setConnStatusText("Connecting");
    const rootRef = ref(dbInstance, "/");

    const unsubscribe = onValue(
      rootRef,
      (snapshot) => {
        const val = snapshot.val();
        if (val) {
          setIsOnline(val.system?.status === "ONLINE" || true);
          setConnStatusText("Online");
          setFirebaseData(val);
        } else {
          setConnStatusText("Connected");
        }
      },
      (error) => {
        console.warn("Firebase RTDB listener notice:", error);
        setConnStatusText("Offline");
        setIsOnline(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Demo simulator for testing telemetry
  useEffect(() => {
    if (!demoMode) return;

    const interval = setInterval(() => {
      setFirebaseData((prev) => {
        const voltNoise = (Math.random() - 0.5) * 0.15;
        const curNoise = (Math.random() - 0.5) * 0.1;
        const newV = Math.max(11.5, Math.min(14.6, (prev.solar?.voltage || 13.4) + voltNoise));
        const newA = (prev.solar?.current || 0.35) + curNoise;
        const newAh = Math.max(0, (prev.battery?.ah || 19.5) + (newA > 0 ? 0.001 : -0.001));

        return {
          ...prev,
          solar: {
            voltage: parseFloat(newV.toFixed(2)),
            current: parseFloat(newA.toFixed(2)),
          },
          battery: {
            ...prev.battery,
            ah: parseFloat(newAh.toFixed(2)),
            state: newA > 0.05 ? "CHARGING" : newA < -0.05 ? "DISCHARGING" : "IDLE",
          },
          energy: {
            ...prev.energy,
            whIn: parseFloat(((prev.energy?.whIn || 142.5) + Math.max(0, newV * newA * (1 / 3600))).toFixed(3)),
          },
          system: {
            status: "ONLINE",
            wifiRSSI: -50 - Math.floor(Math.random() * 8),
            ip: prev.system?.ip || "192.168.1.104",
          },
        };
      });
      setIsOnline(true);
      setConnStatusText("Online");
    }, 2500);

    return () => clearInterval(interval);
  }, [demoMode]);

  // Derived telemetry values based on calibration settings
  const rawV = parseFloat(String(firebaseData.solar?.voltage || 0));
  const rawA = parseFloat(String(firebaseData.solar?.current || 0));
  const rawAh = parseFloat(String(firebaseData.battery?.ah || 0));
  const totIn = parseFloat(String(firebaseData.energy?.whIn || 0));
  const dailyLoadOut = parseFloat(String(firebaseData.energy?.dailyWhOut || 0));

  // Applying offsets
  const finalV = rawV + settings.vOff;
  const finalA = rawA + settings.aOff;
  const finalW = finalV * finalA;
  // USER'S CALIBRATED FORMULA
  const finalAh = Math.max(0, rawAh + settings.baOff);
  const calcPct = Math.min(100, Math.max(0, (finalAh / (settings.batCap || 65)) * 100));

  // Charge / discharge source state calculation
  const currentHour = new Date().getHours();
  let chargeSource = "Idle";
  if (finalA > 0.15) {
    chargeSource = currentHour >= 6 && currentHour < 18 ? "Solar Charging" : "Grid Charging";
  } else if (finalA < -0.15) {
    chargeSource = "Discharging";
  }

  // Backup time calculation
  let backupTimeStr = "--";
  const loadWatts = Math.abs(finalW);
  const batState = (firebaseData.battery?.state || "").toUpperCase();

  if ((batState === "DISCHARGING" || finalA < -0.05) && finalAh > 0) {
    if (loadWatts > 1) {
      const remainingWh = finalAh * finalV;
      const totalHours = remainingWh / loadWatts;
      if (totalHours < 48 && totalHours > 0) {
        const h = Math.floor(totalHours);
        const m = Math.floor((totalHours - h) * 60);
        backupTimeStr = `${h}h ${m}m`;
      } else {
        backupTimeStr = "48h+";
      }
    } else {
      backupTimeStr = "Low Load";
    }
  } else if (batState === "CHARGING" || finalA > 0.05) {
    backupTimeStr = "12h";
  } else {
    backupTimeStr = "Full";
  }

  // Today's summary calculations
  const todaySolarWh = Math.max(0, totIn - whGrid);
  const todayLoadWh = dailyLoadOut || 12.4;
  const currentVoltSafe = finalV > 0 ? finalV : 12.0;
  const derivedAhIn = todaySolarWh / currentVoltSafe;
  const derivedAhOut = todayLoadWh / currentVoltSafe;

  // WiFi signal strength calculation
  const wifiRSSI = typeof firebaseData.system?.wifiRSSI === "number" 
    ? firebaseData.system.wifiRSSI 
    : -54;
  const wifiPct = Math.min(100, Math.max(20, Math.round(((wifiRSSI + 100) / 70) * 100)));

  // Record peak charge and peak load
  useEffect(() => {
    if (finalW > 0.1) {
      if (finalW > maxCharge) {
        setMaxCharge(finalW);
        localStorage.setItem("maxCharge", String(finalW));
      }
    } else if (finalW < -0.1) {
      const absW = Math.abs(finalW);
      if (absW > maxLoad) {
        setMaxLoad(absW);
        localStorage.setItem("maxLoad", String(absW));
      }
    }

    // Solar vs Grid split update
    if (lastWhTotalRef.current === 0) {
      lastWhTotalRef.current = totIn;
    } else if (totIn > lastWhTotalRef.current) {
      const diff = totIn - lastWhTotalRef.current;
      if (currentHour >= 6 && currentHour < 18) {
        const newSolar = whSolar + diff;
        setWhSolar(newSolar);
        localStorage.setItem("whSolar", String(newSolar));
      } else {
        const newGrid = whGrid + diff;
        setWhGrid(newGrid);
        localStorage.setItem("whGrid", String(newGrid));
      }
      lastWhTotalRef.current = totIn;
    }
  }, [finalW, finalV, finalA, totIn, currentHour]);

  // Compute telemetry history points based on the user's selected time range (1h, 3h, 4h, 6h, 12h, 24h)
  const chartDataPoints: ChartDataPoint[] = useMemo(() => {
    return generateHistoryForRange(selectedTimeRange, finalW, finalV, finalA);
  }, [selectedTimeRange, finalW, finalV, finalA]);

  // Toggle relay with Firebase push
  const handleToggleRelay = (key: "inverter" | "line", checked: boolean) => {
    setFirebaseData((prev) => ({
      ...prev,
      relay: {
        ...prev.relay,
        [key]: checked,
      },
    }));

    if (dbInstance) {
      const relayRef = ref(dbInstance, "relay");
      update(relayRef, { [key]: checked }).catch((err) => {
        console.warn("Relay push error:", err);
      });
    }
  };

  const handleSaveSettings = (newSettings: CalibrationSettings) => {
    setSettings(newSettings);
    localStorage.setItem("baOff", String(newSettings.baOff));
    localStorage.setItem("vOff", String(newSettings.vOff));
    localStorage.setItem("aOff", String(newSettings.aOff));
    localStorage.setItem("batCap", String(newSettings.batCap));
  };

  const handleResetAnalytics = () => {
    setMaxCharge(0);
    setMaxLoad(0);
    setWhSolar(0);
    localStorage.setItem("maxCharge", "0");
    localStorage.setItem("maxLoad", "0");
    localStorage.setItem("whSolar", "0");
  };

  const currentDateFormatted = new Date().toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col items-center justify-between px-3 sm:px-6 pt-3 sm:pt-4 pb-28 overflow-x-hidden font-sans">
      <div className="w-full max-w-6xl flex flex-col gap-3.5 sm:gap-4">
        {/* Sleek Compact Header */}
        <header className="flex justify-between items-center select-none py-1 border-b border-white/5 pb-2">
          <div className="flex items-center gap-2.5">
            <div
              id="led-indicator"
              className="w-7 h-7 rounded-full bg-neutral-900 flex items-center justify-center border border-white/5 shrink-0"
            >
              <div
                className={`w-2 h-2 rounded-full ${
                  isOnline
                    ? "bg-[#C6F432] shadow-[0_0_10px_#C6F432]"
                    : "bg-red-500 shadow-[0_0_10px_#ef4444]"
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-[11px] font-bold tracking-[0.2em] text-gray-200 uppercase">
                  Smart Inverter Pro
                </h1>
                <span className="text-[8px] font-mono text-[#C6F432] bg-[#C6F432]/10 px-1.5 py-0.5 rounded font-semibold border border-[#C6F432]/20 uppercase">
                  {connStatusText}
                </span>
              </div>
              <p className="text-[9px] text-gray-500 font-mono tracking-wider">
                {currentDateFormatted} • {firebaseData.system?.ip || "192.168.1.104"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="open-settings-btn"
              onClick={() => setIsSettingsOpen(true)}
              className="h-7 sm:h-8 px-2.5 sm:px-3 rounded-full bg-neutral-900/90 hover:bg-neutral-800 flex items-center gap-1.5 border border-white/10 text-gray-400 hover:text-[#C6F432] transition-colors text-[10px] font-mono"
              title="Calibration & Settings"
              aria-label="Calibration Settings"
            >
              <Sliders className="w-3.5 h-3.5 text-[#C6F432]" />
              <span className="hidden sm:inline">Settings</span>
            </button>
          </div>
        </header>

        {/* 1. HOME TAB: Power Graph UP, Battery Capacity Card, Efficiency Card, and Switches at the VERY BOTTOM */}
        {activeTab === "home" && (
          <div className="flex flex-col gap-3.5 sm:gap-4 animate-in fade-in duration-200">
            {/* Top Row: Battery Capacity Hero (Left) & Power Analytics Graph Card (Right) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-4 items-stretch">
              {/* Battery Capacity Big Hero Card (6 cols) */}
              <div className="lg:col-span-6 xl:col-span-6 sleek-card rounded-[28px] sm:rounded-[32px] p-4 sm:p-5 flex flex-col items-center justify-between relative overflow-hidden">
                <div className="w-full flex justify-between items-center mb-1">
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">
                    Battery Capacity
                  </p>
                  <span className="text-[9px] font-mono text-gray-500 bg-black/40 px-2 py-0.5 rounded-full border border-white/5">
                    {settings.baOff} Ah Offset
                  </span>
                </div>

                {/* SVG Gauge Component */}
                <Gauge
                  percentage={calcPct}
                  chargeSource={chargeSource}
                  batteryAh={finalAh}
                  batteryCapacity={settings.batCap}
                />

                {/* 4 Bottom Columns with Crisp Dividers */}
                <div className="grid grid-cols-4 w-full mt-2 border-t border-white/5 pt-3 font-mono text-center">
                  <div>
                    <p className="text-[8px] text-gray-500 uppercase mb-0.5 font-sans">Current</p>
                    <p className="text-base sm:text-lg font-bold text-white">
                      {finalAh.toFixed(1)}
                      <span className="text-[10px] ml-0.5 text-gray-500 font-sans">Ah</span>
                    </p>
                  </div>
                  <div className="border-l border-white/5">
                    <p className="text-[8px] text-gray-500 uppercase mb-0.5 font-sans">Voltage</p>
                    <p className="text-base sm:text-lg font-bold text-white">
                      {finalV.toFixed(1)}
                      <span className="text-[10px] ml-0.5 text-gray-500 font-sans">V</span>
                    </p>
                  </div>
                  <div className="border-l border-white/5">
                    <p className="text-[8px] text-gray-500 uppercase mb-0.5 font-sans">Load</p>
                    <p className="text-base sm:text-lg font-bold text-[#C6F432]">
                      {Math.abs(finalW).toFixed(0)}
                      <span className="text-[10px] ml-0.5 text-gray-500 font-sans">W</span>
                    </p>
                  </div>
                  <div className="border-l border-white/5">
                    <p className="text-[8px] text-gray-500 uppercase mb-0.5 font-sans">Backup</p>
                    <p className="text-base sm:text-lg font-bold text-cyan-400">{backupTimeStr}</p>
                  </div>
                </div>
              </div>

              {/* Elevated Power Analytics Card & Live Graph (Right 6 cols) */}
              <div className="lg:col-span-6 xl:col-span-6 sleek-card rounded-[28px] sm:rounded-[32px] p-4 sm:p-5 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-2.5">
                    <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#C6F432]" />
                      Power Analytics
                    </p>
                    <span className="text-[8px] text-[#C6F432] font-mono tracking-wider font-bold bg-[#C6F432]/10 px-2 py-0.5 rounded-full border border-[#C6F432]/20">
                      LIVE FEED
                    </span>
                  </div>

                  {/* Interactive Power Chart with Quick Time Selector */}
                  <PowerChart
                    data={chartDataPoints}
                    liveWatts={finalW}
                    selectedRange={selectedTimeRange}
                    onRangeChange={(range) => setSelectedTimeRange(range)}
                    showRangeSelector={true}
                    height={175}
                  />
                </div>

                {/* Daily Solar vs Load quick badges */}
                <div className="grid grid-cols-2 gap-2.5 mt-3 pt-3 border-t border-white/5">
                  <div className="bg-black/40 p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                    <div>
                      <p className="text-[8px] text-gray-500 uppercase font-bold">Peak Solar</p>
                      <p className="text-sm sm:text-base font-bold text-[#C6F432] font-mono">{maxCharge.toFixed(0)}W</p>
                    </div>
                    <Sun className="w-4 h-4 text-[#C6F432]/60" />
                  </div>
                  <div className="bg-black/40 p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                    <div>
                      <p className="text-[8px] text-gray-500 uppercase font-bold">Peak Load</p>
                      <p className="text-sm sm:text-base font-bold text-red-400 font-mono">{maxLoad.toFixed(0)}W</p>
                    </div>
                    <BatteryCharging className="w-4 h-4 text-red-400/60" />
                  </div>
                </div>
              </div>
            </div>

            {/* Middle Section: Efficiency Summary Strip */}
            <div className="sleek-card rounded-[24px] sm:rounded-[28px] p-4 sm:p-4.5">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                <div>
                  <p className="text-[9px] text-gray-500 uppercase font-bold tracking-widest mb-1">
                    WiFi Signal
                  </p>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-mono text-[#C6F432] font-bold">{wifiRSSI} dBm</span>
                    <span className="text-[10px] font-mono text-gray-500">{wifiPct}%</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#C6F432] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_#C6F432]"
                      style={{ width: `${wifiPct}%` }}
                    />
                  </div>
                </div>

                <div className="md:border-l md:border-white/5 md:pl-4">
                  <p className="text-[9px] text-gray-500 uppercase font-bold tracking-widest mb-0.5">
                    Solar Generation
                  </p>
                  <p className="text-lg font-bold text-white font-mono">
                    {whSolar.toFixed(2)} <span className="text-xs text-gray-500 font-sans">kWh</span>
                  </p>
                  <p className="text-[9px] text-gray-500 font-mono">Approx. {derivedAhIn.toFixed(1)} Ah total</p>
                </div>

                <div className="md:border-l md:border-white/5 md:pl-4">
                  <p className="text-[9px] text-gray-500 uppercase font-bold tracking-widest mb-0.5">
                    Today Load Out
                  </p>
                  <p className="text-lg font-bold text-[#C6F432] font-mono">
                    {todayLoadWh.toFixed(1)} <span className="text-xs text-gray-500 font-sans">Wh</span>
                  </p>
                  <p className="text-[9px] text-gray-500 font-mono">Discharged {derivedAhOut.toFixed(2)} Ah</p>
                </div>
              </div>
            </div>

            {/* BOTTOM SECTION: 2 RELAY SWITCHES PLACED AT THE VERY BOTTOM */}
            <div id="bottom-switches-section" className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
              <RelaySwitch
                id="inverter-power"
                label="Inverter Power"
                sublabel="System 220V Output Relay"
                icon={<Power className="w-4 h-4" />}
                checked={firebaseData.relay?.inverter ?? true}
                onChange={(checked) => handleToggleRelay("inverter", checked)}
              />
              <RelaySwitch
                id="line-cut"
                label="Line Cut"
                sublabel="Auto Grid Line Isolation"
                icon={<Zap className="w-4 h-4" />}
                checked={firebaseData.relay?.line ?? false}
                onChange={(checked) => handleToggleRelay("line", checked)}
              />
            </div>
          </div>
        )}

        {/* 2. HISTORY & ANALYTICS TAB: WITH DYNAMIC TIME RANGE SWITCHER (3h, 4h, 6h, etc.) */}
        {activeTab === "stat" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="sleek-card rounded-[40px] p-6 sm:p-8">
              {/* Header & Time Window Selection */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <h2 className="text-base font-bold uppercase tracking-widest text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#C6F432]" />
                    Power Analytics & Telemetry History
                  </h2>
                  <p className="text-xs text-gray-500 font-mono mt-1">
                    Continuous Power Generation & Load Timeline ({selectedTimeRange.toUpperCase()} View)
                  </p>
                </div>

                {/* Time Range Selector Buttons */}
                <div className="flex items-center gap-1.5 bg-black/60 p-1.5 rounded-full border border-white/10 flex-wrap">
                  {TIME_RANGES.map((r) => {
                    const isActive = selectedTimeRange === r.id;
                    return (
                      <button
                        key={r.id}
                        id={`history-time-btn-${r.id}`}
                        onClick={() => setSelectedTimeRange(r.id)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-mono font-bold transition-all ${
                          isActive
                            ? "bg-[#C6F432] text-black shadow-[0_0_12px_rgba(198,244,50,0.4)]"
                            : "text-gray-400 hover:text-white hover:bg-white/5"
                        }`}
                      >
                        {r.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Full Expanded Power Chart for the Chosen Time Range */}
              <PowerChart
                data={chartDataPoints}
                liveWatts={finalW}
                selectedRange={selectedTimeRange}
                onRangeChange={(range) => setSelectedTimeRange(range)}
                showRangeSelector={false}
                height={260}
              />

              {/* 4 Metric Summary Cards for this Time Range */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
                <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                  <p className="text-[9px] text-gray-500 uppercase font-bold mb-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-[#C6F432]" />
                    Peak Charge
                  </p>
                  <p className="text-xl font-bold text-[#C6F432] font-mono">{maxCharge.toFixed(0)}W</p>
                </div>
                <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                  <p className="text-[9px] text-gray-500 uppercase font-bold mb-1 flex items-center gap-1">
                    <TrendingDown className="w-3 h-3 text-red-400" />
                    Peak Load
                  </p>
                  <p className="text-xl font-bold text-red-400 font-mono">{maxLoad.toFixed(0)}W</p>
                </div>
                <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                  <p className="text-[9px] text-gray-500 uppercase font-bold mb-1 flex items-center gap-1">
                    <Sun className="w-3 h-3 text-[#C6F432]" />
                    Ah Generated
                  </p>
                  <p className="text-xl font-bold text-[#C6F432] font-mono">{derivedAhIn.toFixed(2)} Ah</p>
                </div>
                <div className="bg-black/40 p-4 rounded-2xl border border-white/5">
                  <p className="text-[9px] text-gray-500 uppercase font-bold mb-1 flex items-center gap-1">
                    <BatteryCharging className="w-3 h-3 text-red-400" />
                    Ah Discharged
                  </p>
                  <p className="text-xl font-bold text-red-400 font-mono">{derivedAhOut.toFixed(2)} Ah</p>
                </div>
              </div>

              {/* Recent Timeline Samples Table */}
              <div className="mt-8 border-t border-white/5 pt-6">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">
                    Telemetry Samples ({selectedTimeRange})
                  </p>
                  <span className="text-[9px] font-mono text-gray-500">
                    Showing past {TIME_RANGES.find((r) => r.id === selectedTimeRange)?.hours} hours
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
                  {chartDataPoints.slice(-6).reverse().map((pt, idx) => (
                    <div
                      key={idx}
                      className="bg-black/30 p-2.5 rounded-xl border border-white/5 flex flex-col gap-1 font-mono text-[10px]"
                    >
                      <span className="text-gray-500">{pt.time}</span>
                      <span
                        className={`font-bold text-xs ${
                          pt.watts >= 0 ? "text-[#C6F432]" : "text-red-400"
                        }`}
                      >
                        {pt.watts >= 0 ? "+" : ""}
                        {pt.watts.toFixed(1)}W
                      </span>
                      <span className="text-gray-400">{pt.voltage.toFixed(1)}V • {pt.current.toFixed(2)}A</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  id="reset-analytics-btn"
                  onClick={handleResetAnalytics}
                  className="px-6 py-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 text-[10px] text-gray-400 hover:text-white uppercase font-bold tracking-widest border border-white/5 flex items-center gap-2 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Analytics Data</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 3. SETTINGS & HARDWARE TAB */}
        {activeTab === "sys" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Hardware Information Card */}
              <div className="sleek-card rounded-[32px] p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">
                    Hardware Status
                  </p>
                  <span className="text-[10px] text-[#C6F432] font-mono font-bold bg-[#C6F432]/10 px-2 py-0.5 rounded-full">
                    ESP32 Active
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-2 border-b border-white/5">
                    <span className="text-gray-400">Node IP Address</span>
                    <span className="font-mono text-white">{firebaseData.system?.ip || "192.168.1.104"}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-white/5">
                    <span className="text-gray-400">WiFi Signal RSSI</span>
                    <span className="font-mono text-[#C6F432]">{wifiRSSI} dBm ({wifiPct}%)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-white/5">
                    <span className="text-gray-400">Firebase RTDB</span>
                    <span className="font-mono text-gray-300">inverter-and-solar</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-gray-400">Calibrated Offset</span>
                    <span className="font-mono text-[#C6F432] font-bold">{settings.baOff} Ah</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions & Simulator Card */}
              <div className="sleek-card rounded-[32px] p-6 flex flex-col justify-between space-y-6">
                <div>
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-2">
                    Telemetry Simulator
                  </p>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4">
                    Enable live waves to test inverter telemetry, relay switching, and solar curve visualizations.
                  </p>
                  <div className="flex items-center justify-between bg-black/40 p-4 rounded-2xl border border-white/5">
                    <span className="text-xs text-gray-300 font-bold">Simulator Feed</span>
                    <label className="sleek-switch select-none cursor-pointer">
                      <input
                        type="checkbox"
                        checked={demoMode}
                        onChange={(e) => setDemoMode(e.target.checked)}
                      />
                      <span className="sleek-slider"></span>
                    </label>
                  </div>
                </div>

                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-full py-3.5 rounded-full bg-[#C6F432] hover:bg-[#b5e02c] text-black font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-[0_4px_15px_rgba(198,244,50,0.3)] transition-all"
                >
                  <Sliders className="w-4 h-4" />
                  <span>Open Calibration Modal</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Sleek Floating Pill Navigation Bar */}
      <nav className="sleek-nav" aria-label="Main Navigation">
        <button
          id="nav-home-btn"
          onClick={() => setActiveTab("home")}
          className={`px-6 sm:px-8 py-2.5 sm:py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
            activeTab === "home"
              ? "bg-[#C6F432] text-black shadow-[0_4px_15px_rgba(198,244,50,0.35)]"
              : "hover:bg-white/5 text-gray-500"
          }`}
        >
          Home
        </button>
        <button
          id="nav-history-btn"
          onClick={() => setActiveTab("stat")}
          className={`px-6 sm:px-8 py-2.5 sm:py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
            activeTab === "stat"
              ? "bg-[#C6F432] text-black shadow-[0_4px_15px_rgba(198,244,50,0.35)]"
              : "hover:bg-white/5 text-gray-500"
          }`}
        >
          History
        </button>
        <button
          id="nav-settings-btn"
          onClick={() => setActiveTab("sys")}
          className={`px-6 sm:px-8 py-2.5 sm:py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
            activeTab === "sys"
              ? "bg-[#C6F432] text-black shadow-[0_4px_15px_rgba(198,244,50,0.35)]"
              : "hover:bg-white/5 text-gray-500"
          }`}
        >
          Settings
        </button>
      </nav>

      {/* Calibration Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={handleSaveSettings}
        rawAh={rawAh}
        rawVoltage={rawV}
        rawCurrent={rawA}
      />
    </div>
  );
}
