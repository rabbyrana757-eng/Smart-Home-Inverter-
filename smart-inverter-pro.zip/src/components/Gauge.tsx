import React from "react";

interface GaugeProps {
  percentage: number;
  chargeSource: string;
  batteryAh: number;
  batteryCapacity: number;
}

export const Gauge: React.FC<GaugeProps> = ({
  percentage,
  chargeSource,
  batteryAh,
  batteryCapacity,
}) => {
  const clampedPct = Math.min(100, Math.max(0, percentage));
  const arcLength = 251.2;
  const offset = arcLength - (arcLength * clampedPct) / 100;

  // Gauge color based on percentage
  let strokeColor = "#C6F432";
  if (clampedPct <= 15) strokeColor = "#EF4444";
  else if (clampedPct <= 30) strokeColor = "#F59E0B";

  return (
    <div id="gauge-container" className="relative flex flex-col items-center justify-center w-full">
      <div className="relative w-[300px] sm:w-[340px] h-[160px] flex items-center justify-center">
        <svg
          id="battery-gauge-svg"
          className="w-full h-full overflow-visible"
          viewBox="0 0 200 100"
        >
          {/* Subtle Glow filter */}
          <defs>
            <filter id="gaugeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="5" floodColor={strokeColor} floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Background Track */}
          <path
            d="M20,90 A80,80 0 0,1 180,90"
            fill="none"
            stroke="#1a1a1a"
            strokeWidth="12"
            strokeLinecap="round"
          />

          {/* Active Progress Arc */}
          <path
            d="M20,90 A80,80 0 0,1 180,90"
            fill="none"
            stroke={strokeColor}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray="251.2"
            strokeDashoffset={offset}
            filter="url(#gaugeGlow)"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Center Percentage & Status Label */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pt-8 pointer-events-none">
          <div className="flex items-baseline">
            <h2
              id="bat-pct-display"
              className="text-6xl sm:text-7xl font-bold text-white tracking-tighter"
            >
              {clampedPct.toFixed(0)}
            </h2>
            <span className="text-3xl font-bold text-[#C6F432] ml-0.5">%</span>
          </div>

          <p
            id="charge-source-badge"
            className="text-[10px] text-[#C6F432] uppercase tracking-[0.4em] font-black mt-1.5 flex items-center gap-1.5"
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                chargeSource.toLowerCase().includes("charg")
                  ? "bg-[#C6F432] animate-pulse"
                  : chargeSource.toLowerCase().includes("discharg")
                  ? "bg-amber-400 animate-pulse"
                  : "bg-gray-500"
              }`}
            />
            {chargeSource}
          </p>
        </div>
      </div>
    </div>
  );
};
