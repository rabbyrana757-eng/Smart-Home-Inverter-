import React, { useState } from "react";
import { ChartDataPoint } from "../types";
import { TimeRange, TIME_RANGES } from "../utils/historyData";
import { Clock, TrendingUp, Zap } from "lucide-react";

interface PowerChartProps {
  data: ChartDataPoint[];
  liveWatts?: number;
  selectedRange?: TimeRange;
  onRangeChange?: (range: TimeRange) => void;
  showRangeSelector?: boolean;
  height?: number;
}

export const PowerChart: React.FC<PowerChartProps> = ({
  data,
  liveWatts = 0,
  selectedRange = "3h",
  onRangeChange,
  showRangeSelector = true,
  height = 200,
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const chartPoints = data && data.length >= 2 ? data : [];

  if (chartPoints.length < 2) {
    const sampleBars = [35, 50, 68, 42, 85, 96, 62, 30, 48, 76, 45, 60, 80, 55, 90];
    return (
      <div id="power-chart-feed" className="w-full flex flex-col justify-end">
        <div className="h-44 w-full flex items-end gap-1.5 px-2 py-2">
          {sampleBars.map((heightPct, idx) => (
            <div
              key={idx}
              style={{ height: `${heightPct}%` }}
              className="flex-grow rounded-t-sm transition-all duration-500 bg-[#C6F432]/40 hover:bg-[#C6F432]"
            />
          ))}
        </div>
      </div>
    );
  }

  const width = 600;
  const padding = { top: 18, right: 16, bottom: 24, left: 40 };

  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const values = chartPoints.map((d) => d.watts);
  const rawMin = Math.min(...values);
  const rawMax = Math.max(...values);

  // Compute adaptive scales
  const minVal = Math.min(rawMin, -20);
  const maxVal = Math.max(rawMax, 60);
  const range = maxVal - minVal || 1;

  const getX = (index: number) => {
    return padding.left + (index / (chartPoints.length - 1)) * chartWidth;
  };

  const getY = (val: number) => {
    const normalized = (val - minVal) / range;
    return padding.top + chartHeight - normalized * chartHeight;
  };

  const points = chartPoints.map((d, i) => `${getX(i)},${getY(d.watts)}`);
  const pathD = `M ${points.join(" L ")}`;

  const zeroY = Math.max(padding.top, Math.min(height - padding.bottom, getY(0)));
  const areaD = `M ${getX(0)},${zeroY} L ${points.join(" L ")} L ${getX(
    chartPoints.length - 1
  )},${zeroY} Z`;

  const hoveredPoint = hoveredIdx !== null ? chartPoints[hoveredIdx] : null;

  // Window statistics
  const avgWatts = values.reduce((a, b) => a + b, 0) / values.length;
  const peakWatts = Math.max(...values);

  return (
    <div id="power-chart-wrapper" className="relative w-full flex flex-col gap-3 select-none">
      {/* Time Range Selector & Stats Header */}
      {showRangeSelector && onRangeChange && (
        <div className="flex flex-wrap items-center justify-between gap-2 pb-1 border-b border-white/5">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-[#C6F432]" />
            <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
              Time Range:
            </span>
          </div>

          <div className="flex items-center gap-1 bg-black/50 p-1 rounded-full border border-white/5">
            {TIME_RANGES.map((r) => {
              const isActive = selectedRange === r.id;
              return (
                <button
                  key={r.id}
                  id={`range-btn-${r.id}`}
                  onClick={() => onRangeChange(r.id)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold transition-all ${
                    isActive
                      ? "bg-[#C6F432] text-black shadow-[0_0_10px_rgba(198,244,50,0.3)]"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  }`}
                  title={`View ${r.hours} Hours timeline`}
                >
                  {r.label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* SVG Chart Area */}
      <div className="relative w-full overflow-hidden">
        <svg
          id="power-chart-svg"
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible"
          onMouseLeave={() => setHoveredIdx(null)}
        >
          <defs>
            <linearGradient id="chartGradientSleek" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#C6F432" stopOpacity="0.32" />
              <stop offset="70%" stopColor="#C6F432" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#C6F432" stopOpacity="0.0" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#C6F432" floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Horizontal grid lines */}
          {[maxVal, (maxVal + minVal) / 2, 0, minVal].map((val, idx) => {
            const y = getY(val);
            if (y < padding.top - 2 || y > height - padding.bottom + 2) return null;
            const isZero = Math.abs(val) < 0.5;
            return (
              <g key={idx}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke={isZero ? "rgba(255,255,255,0.18)" : "rgba(255,255,255,0.04)"}
                  strokeDasharray={isZero ? "4,4" : "2,2"}
                  strokeWidth={isZero ? 1.2 : 1}
                />
                <text
                  x={padding.left - 6}
                  y={y + 3}
                  fill={isZero ? "#888" : "#555"}
                  fontSize="8"
                  textAnchor="end"
                  fontFamily="monospace"
                  fontWeight={isZero ? "bold" : "normal"}
                >
                  {Math.round(val)}W
                </text>
              </g>
            );
          })}

          {/* Shaded Area fill */}
          <path d={areaD} fill="url(#chartGradientSleek)" />

          {/* Neon Line Path */}
          <path
            d={pathD}
            fill="none"
            stroke="#C6F432"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#glow)"
          />

          {/* Interactive Mouse Hover Columns */}
          {chartPoints.map((_, idx) => {
            const x = getX(idx);
            const colWidth = chartWidth / (chartPoints.length - 1);
            return (
              <rect
                key={idx}
                x={x - colWidth / 2}
                y={padding.top}
                width={colWidth}
                height={chartHeight}
                fill="transparent"
                onMouseEnter={() => setHoveredIdx(idx)}
                className="cursor-crosshair"
              />
            );
          })}

          {/* Hover Crosshair & Point Indicator */}
          {hoveredIdx !== null && hoveredPoint && (
            <g>
              <line
                x1={getX(hoveredIdx)}
                y1={padding.top}
                x2={getX(hoveredIdx)}
                y2={height - padding.bottom}
                stroke="#C6F432"
                strokeDasharray="2,2"
                strokeWidth="1"
                opacity="0.85"
              />
              <circle
                cx={getX(hoveredIdx)}
                cy={getY(hoveredPoint.watts)}
                r="5"
                fill="#080808"
                stroke="#C6F432"
                strokeWidth="2.5"
                filter="url(#glow)"
              />
            </g>
          )}

          {/* Timeline Start, Mid, End Labels */}
          {chartPoints.length > 0 && (
            <g>
              <text
                x={padding.left}
                y={height - 6}
                fill="#777"
                fontSize="8"
                textAnchor="start"
                fontFamily="monospace"
              >
                {chartPoints[0]?.time}
              </text>
              {chartPoints.length > 4 && (
                <text
                  x={width / 2}
                  y={height - 6}
                  fill="#555"
                  fontSize="8"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  {chartPoints[Math.floor(chartPoints.length / 2)]?.time}
                </text>
              )}
              <text
                x={width - padding.right}
                y={height - 6}
                fill="#C6F432"
                fontSize="8"
                textAnchor="end"
                fontFamily="monospace"
                fontWeight="bold"
              >
                {chartPoints[chartPoints.length - 1]?.time} (Live)
              </text>
            </g>
          )}
        </svg>

        {/* Hover Floating Tooltip */}
        {hoveredPoint && (
          <div
            id="chart-tooltip"
            className="absolute top-2 right-2 px-3 py-1.5 rounded-xl bg-[#111111]/95 border border-[#C6F432]/30 text-[10px] font-mono shadow-2xl flex items-center gap-3 backdrop-blur pointer-events-none transition-all"
          >
            <span className="text-gray-400">{hoveredPoint.time}</span>
            <span
              className={`font-bold flex items-center gap-1 ${
                hoveredPoint.watts >= 0 ? "text-[#C6F432]" : "text-red-400"
              }`}
            >
              {hoveredPoint.watts >= 0 ? "+" : ""}
              {hoveredPoint.watts.toFixed(1)}W
            </span>
            <span className="text-gray-400">{hoveredPoint.voltage.toFixed(1)}V</span>
            <span className="text-gray-400">{hoveredPoint.current.toFixed(2)}A</span>
          </div>
        )}
      </div>

      {/* Mini Window Summary Footer */}
      <div className="flex items-center justify-between text-[9px] font-mono text-gray-500 pt-1 border-t border-white/5">
        <span className="flex items-center gap-1">
          <TrendingUp className="w-3 h-3 text-[#C6F432]" />
          Peak: <strong className="text-white">{peakWatts.toFixed(0)}W</strong>
        </span>
        <span>
          Avg: <strong className="text-gray-300">{avgWatts.toFixed(1)}W</strong>
        </span>
        <span className="flex items-center gap-1">
          <Zap className="w-3 h-3 text-[#C6F432]" />
          Live: <strong className="text-[#C6F432]">{liveWatts.toFixed(0)}W</strong>
        </span>
      </div>
    </div>
  );
};
