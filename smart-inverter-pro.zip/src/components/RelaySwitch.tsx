import React from "react";

interface RelaySwitchProps {
  id: string;
  label: string;
  sublabel?: string;
  icon?: React.ReactNode;
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}

export const RelaySwitch: React.FC<RelaySwitchProps> = ({
  id,
  label,
  sublabel,
  icon,
  checked,
  onChange,
  disabled = false,
}) => {
  return (
    <div
      id={`relay-card-${id}`}
      className="sleek-card rounded-[32px] p-6 flex justify-between items-center transition-all hover:border-white/10"
    >
      <div className="flex items-center gap-3.5">
        {icon && (
          <div
            className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors ${
              checked
                ? "bg-[#C6F432]/15 text-[#C6F432] border border-[#C6F432]/20"
                : "bg-neutral-900 text-gray-500 border border-white/5"
            }`}
          >
            {icon}
          </div>
        )}
        <div>
          <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-0.5">
            {label}
          </p>
          <p className="text-sm text-gray-300 font-medium">
            {sublabel || (checked ? "Active" : "Disabled")}
          </p>
        </div>
      </div>

      <label className="sleek-switch select-none cursor-pointer" aria-label={`Toggle ${label}`}>
        <input
          id={`toggle-${id}`}
          type="checkbox"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange(e.target.checked)}
        />
        <span className="sleek-slider"></span>
      </label>
    </div>
  );
};
