import React, { useState } from "react";
import { CalibrationSettings } from "../types";
import { Sliders, RotateCcw, Check, Zap, Info, X } from "lucide-react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CalibrationSettings;
  onSave: (newSettings: CalibrationSettings) => void;
  rawAh: number;
  rawVoltage: number;
  rawCurrent: number;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
  rawAh,
  rawVoltage,
  rawCurrent,
}) => {
  const [baOff, setBaOff] = useState<number>(settings.baOff);
  const [vOff, setVOff] = useState<number>(settings.vOff);
  const [aOff, setAOff] = useState<number>(settings.aOff);
  const [batCap, setBatCap] = useState<number>(settings.batCap);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  // Real-time calculation previews
  const previewAh = Math.max(0, rawAh + baOff);
  const previewV = rawVoltage + vOff;
  const previewA = rawCurrent + aOff;
  const previewPct = Math.min(100, Math.max(0, (previewAh / (batCap || 65)) * 100));

  const handleSave = () => {
    onSave({
      vOff,
      aOff,
      baOff,
      batCap,
      whGridInitial: settings.whGridInitial,
    });
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 600);
  };

  const handleResetDefaults = () => {
    // Reset to user's desired calibration (-15 Ah offset to reduce 39.5 by 35 to 4.5 Ah)
    setBaOff(-15);
    setVOff(0);
    setAOff(0);
    setBatCap(65);
  };

  const handleSetExactAh = (targetAh: number) => {
    // Calculate required offset for target
    const calculatedOffset = targetAh - rawAh;
    setBaOff(Number(calculatedOffset.toFixed(1)));
  };

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <div
        id="settings-modal-card"
        className="w-full max-w-md bg-[#121212] border border-white/10 rounded-3xl p-6 text-white shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#C6F432]/10 text-[#C6F432] flex items-center justify-center border border-[#C6F432]/20">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider">Sensor Calibration</h3>
              <p className="text-[10px] text-gray-500 font-mono">Offsets & Battery Setup</p>
            </div>
          </div>
          <button
            id="close-settings-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-900 border border-white/5 flex items-center justify-center text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Highlight Banner: 35 Ah Reduction explanation */}
        <div
          id="ah-calibration-alert"
          className="p-3.5 rounded-2xl bg-[#C6F432]/10 border border-[#C6F432]/25 text-[11px] space-y-1.5"
        >
          <div className="flex items-center gap-1.5 font-bold text-[#C6F432] uppercase tracking-wide">
            <Zap className="w-3.5 h-3.5" />
            <span>ব্যাটারি Ah ক্যালিব্রেশন (Battery Ah Calibrated)</span>
          </div>
          <p className="text-gray-300 leading-relaxed">
            আগে <span className="text-white font-mono font-bold">+20 Ah</span> যোগ থাকার কারণে ৩৯.৫ Ah দেখাচ্ছিল।
            এখন <span className="text-[#C6F432] font-mono font-bold">-15 Ah</span> অফসেট সেট করা হয়েছে, যাতে ৩৫ Ah কমে ঠিক <span className="text-[#C6F432] font-mono font-bold">~৪.৫ Ah</span> দেখায়।
          </p>
          <div className="flex items-center gap-2 pt-1">
            <span className="text-[10px] text-gray-400">Quick Targets:</span>
            <button
              type="button"
              onClick={() => handleSetExactAh(4.5)}
              className="px-2 py-0.5 rounded bg-[#C6F432] text-black font-bold text-[10px] hover:bg-[#b5e02c]"
            >
              Set to 4.5 Ah
            </button>
            <button
              type="button"
              onClick={() => setBaOff(-15)}
              className="px-2 py-0.5 rounded bg-neutral-800 text-gray-200 border border-white/10 text-[10px]"
            >
              -15 Ah Offset
            </button>
          </div>
        </div>

        {/* Live Calculation Preview Box */}
        <div
          id="live-preview-box"
          className="grid grid-cols-3 gap-2 p-3 bg-neutral-950/80 rounded-2xl border border-white/5 text-center font-mono"
        >
          <div>
            <span className="text-[8px] uppercase text-gray-500 font-bold block">Raw Ah</span>
            <span className="text-xs text-gray-400 font-semibold">{rawAh.toFixed(1)} Ah</span>
          </div>
          <div className="border-x border-white/5">
            <span className="text-[8px] uppercase text-[#C6F432] font-bold block">Offset</span>
            <span className="text-xs text-[#C6F432] font-bold">
              {baOff >= 0 ? `+${baOff}` : baOff} Ah
            </span>
          </div>
          <div>
            <span className="text-[8px] uppercase text-white font-bold block">Final Display</span>
            <span className="text-xs text-brand font-bold text-[#C6F432]">
              {previewAh.toFixed(1)} Ah ({previewPct.toFixed(0)}%)
            </span>
          </div>
        </div>

        {/* Form Controls */}
        <div className="space-y-4 text-xs">
          {/* Battery Ah Offset (baOff) */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label htmlFor="input-baoff" className="font-bold text-gray-300 uppercase text-[10px] tracking-wider">
                Battery Ah Offset (<code className="text-[#C6F432]">baOff</code>)
              </label>
              <span className="font-mono text-[#C6F432] font-bold">{baOff} Ah</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                id="input-baoff-range"
                type="range"
                min="-50"
                max="50"
                step="0.5"
                value={baOff}
                onChange={(e) => setBaOff(parseFloat(e.target.value))}
                className="w-full accent-[#C6F432] cursor-pointer"
              />
              <input
                id="input-baoff"
                type="number"
                step="0.1"
                value={baOff}
                onChange={(e) => setBaOff(parseFloat(e.target.value) || 0)}
                className="w-20 px-2.5 py-1 rounded-xl bg-neutral-900 border border-white/10 text-right font-mono text-xs focus:outline-none focus:border-[#C6F432]"
              />
            </div>
            <p className="text-[9px] text-gray-500">
              Set to <span className="text-white font-mono">-15</span> to reduce displayed Ah by 35 (so ~39.5 Ah becomes ~4.5 Ah).
            </p>
          </div>

          {/* Battery Capacity (batCap) */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label htmlFor="input-batcap" className="font-bold text-gray-300 uppercase text-[10px] tracking-wider">
                Battery Capacity (<code className="text-gray-400">batCap</code>)
              </label>
              <span className="font-mono text-gray-300 font-bold">{batCap} Ah</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                id="input-batcap-range"
                type="range"
                min="10"
                max="250"
                step="5"
                value={batCap}
                onChange={(e) => setBatCap(parseFloat(e.target.value))}
                className="w-full accent-[#C6F432] cursor-pointer"
              />
              <input
                id="input-batcap"
                type="number"
                value={batCap}
                onChange={(e) => setBatCap(parseFloat(e.target.value) || 65)}
                className="w-20 px-2.5 py-1 rounded-xl bg-neutral-900 border border-white/10 text-right font-mono text-xs focus:outline-none focus:border-[#C6F432]"
              />
            </div>
            <p className="text-[9px] text-gray-500">Total rated battery capacity in Ampere-hours (default 65Ah).</p>
          </div>

          {/* Voltage Offset (vOff) & Current Offset (aOff) */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="space-y-1">
              <label htmlFor="input-voff" className="font-bold text-gray-400 uppercase text-[9px] tracking-wider block">
                Voltage Offset (V)
              </label>
              <input
                id="input-voff"
                type="number"
                step="0.1"
                value={vOff}
                onChange={(e) => setVOff(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-900 border border-white/10 font-mono text-xs focus:outline-none focus:border-[#C6F432]"
              />
              <span className="text-[9px] text-gray-500 font-mono block">Preview: {previewV.toFixed(1)}V</span>
            </div>

            <div className="space-y-1">
              <label htmlFor="input-aoff" className="font-bold text-gray-400 uppercase text-[9px] tracking-wider block">
                Current Offset (A)
              </label>
              <input
                id="input-aoff"
                type="number"
                step="0.05"
                value={aOff}
                onChange={(e) => setAOff(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-900 border border-white/10 font-mono text-xs focus:outline-none focus:border-[#C6F432]"
              />
              <span className="text-[9px] text-gray-500 font-mono block">Preview: {previewA.toFixed(2)}A</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-3 border-t border-white/5">
          <button
            id="reset-calibration-btn"
            type="button"
            onClick={handleResetDefaults}
            className="px-3.5 py-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-gray-400 hover:text-white border border-white/5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Defaults</span>
          </button>

          <button
            id="save-calibration-btn"
            type="button"
            onClick={handleSave}
            className="flex-1 py-2.5 rounded-2xl bg-[#C6F432] hover:bg-[#b5e02c] text-black font-bold uppercase tracking-widest text-[11px] flex items-center justify-center gap-2 shadow-[0_4px_15px_rgba(198,244,50,0.3)] transition-all active:scale-[0.98]"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4" />
                <span>Saved!</span>
              </>
            ) : (
              <>
                <span>Save Calibration</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
