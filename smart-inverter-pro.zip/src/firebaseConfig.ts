import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase, ref, onValue, set, update, Database } from "firebase/database";
import { getAuth, signInWithEmailAndPassword, Auth } from "firebase/auth";

export const firebaseConfig = {
  apiKey: "AIzaSyDqO22UXsPCRzZcsezLE8mDn_ffAzf0F5w",
  authDomain: "inverter-and-solar.firebaseapp.com",
  databaseURL: "https://inverter-and-solar-default-rtdb.firebaseio.com",
  projectId: "inverter-and-solar",
  storageBucket: "inverter-and-solar.firebasestorage.app",
  messagingSenderId: "232410148433",
  appId: "1:232410148433:web:f794c17a628407dac4d270",
  measurementId: "G-XPV0CHRK14",
};

let appInstance: ReturnType<typeof initializeApp> | null = null;
let dbInstance: Database | null = null;
let authInstance: Auth | null = null;

try {
  appInstance = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  dbInstance = getDatabase(appInstance);
  authInstance = getAuth(appInstance);
  // Auto sign-in
  signInWithEmailAndPassword(authInstance, "rabbyrana757@gmail.com", "RABBY.1234").catch((err) => {
    console.warn("Firebase Auth Notice:", err.message);
  });
} catch (e) {
  console.error("Firebase init error:", e);
}

export { appInstance, dbInstance, authInstance, ref, onValue, set, update };
