export interface InverterFirebaseData {
  solar?: {
    voltage?: number;
    current?: number;
  };
  battery?: {
    ah?: number;
    state?: string;
    level?: number;
  };
  energy?: {
    whIn?: number;
    whOut?: number;
    dailyWhOut?: number;
  };
  relay?: {
    inverter?: boolean;
    line?: boolean;
  };
  system?: {
    status?: string;
    wifiRSSI?: number | string;
    ip?: string;
    uptime?: number;
    lastSeen?: number;
  };
}

export interface CalibrationSettings {
  vOff: number; // Voltage offset (V)
  aOff: number; // Current offset (A)
  baOff: number; // Battery Ah offset (default -15 to reduce 39.5 Ah to 4.5 Ah)
  batCap: number; // Battery capacity in Ah (default 65 Ah)
  whGridInitial: number;
}

export interface ChartDataPoint {
  time: string;
  watts: number;
  voltage: number;
  current: number;
}
