import { ChartDataPoint } from "../types";

export type TimeRange = "1h" | "3h" | "4h" | "6h" | "12h" | "24h";

export interface TimeRangeOption {
  id: TimeRange;
  label: string;
  hours: number;
  intervalMinutes: number;
}

export const TIME_RANGES: TimeRangeOption[] = [
  { id: "1h", label: "1h", hours: 1, intervalMinutes: 2 },
  { id: "3h", label: "3h (৩ ঘন্টা)", hours: 3, intervalMinutes: 5 },
  { id: "4h", label: "4h (৪ ঘন্টা)", hours: 4, intervalMinutes: 6 },
  { id: "6h", label: "6h (৬ ঘন্টা)", hours: 6, intervalMinutes: 10 },
  { id: "12h", label: "12h", hours: 12, intervalMinutes: 20 },
  { id: "24h", label: "24h", hours: 24, intervalMinutes: 30 },
];

/**
 * Generate smooth, realistic continuous telemetry history for any given time range,
 * naturally converging to the current live watts, voltage, and current.
 */
export function generateHistoryForRange(
  range: TimeRange,
  currentWatts: number,
  currentVoltage: number,
  currentCurrent: number
): ChartDataPoint[] {
  const rangeConfig = TIME_RANGES.find((r) => r.id === range) || TIME_RANGES[1];
  const totalMinutes = rangeConfig.hours * 60;
  const step = rangeConfig.intervalMinutes;
  const numPoints = Math.floor(totalMinutes / step);

  const now = new Date();
  const points: ChartDataPoint[] = [];

  for (let i = numPoints; i >= 0; i--) {
    const pointTime = new Date(now.getTime() - i * step * 60 * 1000);
    const hour = pointTime.getHours();
    const minute = pointTime.getMinutes();
    const timeStr = pointTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    // If it is the latest point (i === 0), use the exact live reading
    if (i === 0) {
      points.push({
        time: timeStr,
        watts: parseFloat(currentWatts.toFixed(1)),
        voltage: parseFloat(currentVoltage.toFixed(1)),
        current: parseFloat(currentCurrent.toFixed(2)),
      });
      continue;
    }

    // Realistic solar and load power pattern
    // Solar production active between 6 AM and 6 PM with peak around 12:30 PM
    let baseSolarWatts = 0;
    if (hour >= 6 && hour < 18) {
      const solarPeakHour = 12.5;
      const hoursFromPeak = Math.abs(hour + minute / 60 - solarPeakHour);
      const solarFactor = Math.max(0, 1 - Math.pow(hoursFromPeak / 6, 2));
      baseSolarWatts = solarFactor * 320; // Up to 320W peak
    }

    // Load fluctuates between 20W (night standby) and 180W (active appliances)
    const loadFactor =
      hour >= 18 || hour <= 7 ? 40 + Math.sin(i * 0.4) * 15 : 90 + Math.cos(i * 0.3) * 45;

    // Inverter net power: positive when solar charging > load, negative when discharging
    let netWatts = baseSolarWatts - loadFactor;

    // Add slight organic noise
    const noise = Math.sin(i * 0.8) * 8 + Math.cos(i * 1.5) * 5;
    netWatts += noise;

    // Smooth transition approaching the current live reading
    const blendFactor = Math.max(0, 1 - i / 6);
    netWatts = netWatts * (1 - blendFactor) + currentWatts * blendFactor;

    // Voltage calculation: 11.8V to 14.4V
    const simVoltage = 12.6 + (netWatts > 0 ? 1.2 : -0.6) + Math.sin(i * 0.2) * 0.2;
    const simCurrent = netWatts / (simVoltage || 12);

    points.push({
      time: timeStr,
      watts: parseFloat(netWatts.toFixed(1)),
      voltage: parseFloat(simVoltage.toFixed(1)),
      current: parseFloat(simCurrent.toFixed(2)),
    });
  }

  return points;
}
